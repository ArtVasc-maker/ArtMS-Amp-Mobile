# Modeling notes — AmpCore 0.1

## AVT150 control topology represented

- Clean: Gain, Bright, Volume and its own three-band Clean Tone EQ.
- OD1: Gain, Scoop and Volume.
- OD2: Gain, Scoop and Volume.
- Overdrive Tone: one Bass/Middle/Treble section shared by OD1 and OD2.
- Master: Volume and Presence.

This topology matters: the Clean EQ must not accidentally modify the two Overdrive channels, and the Overdrive EQ must be common to OD1 and OD2. The Scoop toggles remain independent.

## Signal flow (first approximation)

```text
Input conditioning / low cut
          |
          +-- Clean: gain -> bright (optional) -> soft nonlinear stages -> Clean EQ
          |
          +-- OD1: gain -> two nonlinear stages -> OD EQ -> OD1 Scoop contour (optional)
          |
          +-- OD2: gain -> three nonlinear stages -> OD EQ -> OD2 Scoop contour (optional)
          |
      Channel Volume
          |
      Power-stage soft saturation + envelope-dependent supply compression
          |
      Master Volume + Presence
          |
      Cabinet high-pass / resonance / low-pass (optional)
          |
      DC blocker + output ceiling
```

The filter shapes and nonlinear stages are engineering approximations intended to create distinct, controllable channels. They are not extracted component values or a verified reproduction of Marshall's proprietary implementation.

## Parameters

All physical-style knobs use a normalized 0–10 range. Five is the neutral position for EQ and a nominal midpoint for gain/volume controls. `powerSag` and `cabinetResonance` are ArtMS experimental controls, not AVT150 panel controls.

## Reference

Marshall, *AVT150/AVT150H & AVT275 Owner's Manual*, Front Panel Features, approximately pp. 6–9 in the manual PDF. The manual describes the Clean Gain/Bright/Volume and dedicated Clean Tone EQ, the OD1/OD2 Gain/Scoop/Volume controls, the shared Overdrive Tone EQ and Master Volume/Presence.

Manual PDF: https://images.thomann.de/pics/atg/atgdata/document/manual/144488_marshall_avt150150h275.pdf
