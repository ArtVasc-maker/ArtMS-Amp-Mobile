cmake_minimum_required(VERSION 3.22)
project(ArtMS_Amp_Mobile VERSION 0.1.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

add_library(artms_ampcore STATIC
    src/AmpCore.cpp
    src/WavIO.cpp
)
target_include_directories(artms_ampcore PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/src)
target_compile_options(artms_ampcore PRIVATE
    $<$<CXX_COMPILER_ID:GNU,Clang>:-O3 -Wall -Wextra -Wpedantic -fno-math-errno>
)

option(ARTMS_BUILD_TESTS "Build standalone AmpCore tests" ON)
if(ARTMS_BUILD_TESTS)
    enable_testing()
    add_executable(artms_ampcore_tests tests/AmpCoreTests.cpp)
    target_link_libraries(artms_ampcore_tests PRIVATE artms_ampcore)
    add_test(NAME AmpCoreTests COMMAND artms_ampcore_tests)
endif()

find_package(Qt6 6.6 QUIET COMPONENTS Core Gui Qml Quick QuickControls2 Multimedia Concurrent)
if(Qt6_FOUND)
    qt_standard_project_setup(REQUIRES 6.6)
    qt_add_executable(artms_amp_mobile
        src/main.cpp
        src/AmpController.cpp
        src/AmpController.h
    )
    qt_add_qml_module(artms_amp_mobile
        URI ArtMS.AmpMobile
        VERSION 1.0
        QML_FILES
            qml/Main.qml
            qml/Knob.qml
    )
    target_link_libraries(artms_amp_mobile PRIVATE
        artms_ampcore
        Qt6::Core Qt6::Gui Qt6::Qml Qt6::Quick Qt6::QuickControls2
        Qt6::Multimedia Qt6::Concurrent
    )
    if(ANDROID)
        set_property(TARGET artms_amp_mobile PROPERTY
            QT_ANDROID_PACKAGE_SOURCE_DIR "${CMAKE_CURRENT_SOURCE_DIR}/android")
        set_property(TARGET artms_amp_mobile PROPERTY QT_ANDROID_PACKAGE_NAME "org.artms.amplake")
        set_property(TARGET artms_amp_mobile PROPERTY QT_ANDROID_APP_NAME "ArtMS Amp")
        set_property(TARGET artms_amp_mobile PROPERTY QT_ANDROID_VERSION_CODE 1)
        set_property(TARGET artms_amp_mobile PROPERTY QT_ANDROID_VERSION_NAME "0.1.0")
    endif()
    qt_finalize_executable(artms_amp_mobile)
else()
    message(STATUS "Qt 6.6+ not found: building only the standalone C++ AmpCore and tests.")
endif()
