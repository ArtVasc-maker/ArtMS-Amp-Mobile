# ArtMS Amp Mobile — 0.1.0

Primeira aplicação nativa Android do ArtMS para testar a modelagem do amplificador a partir de uma gravação DI. A interface é Qt Quick/QML; o processamento é uma biblioteca C++20 independente (`artms_ampcore`), que poderá ser reutilizada posteriormente pelo ArtMS_DSP.

> **Estado honesto da entrega:** o AmpCore C++20 foi compilado neste ambiente e seus testes passaram. O projeto Android/QML está preparado no código-fonte, mas ainda não foi compilado como APK nem executado em um telefone: este ambiente não possui Qt 6, Android SDK ou Android NDK instalados. Portanto, este ZIP contém o projeto-fonte, não um APK instalável.

## Controles implementados

A organização dos controles segue o painel e o manual do Marshall Valvestate 2000 AVT150:

| Seção | Controles |
|---|---|
| Clean | Gain, Volume, Bright |
| Clean Tone | Bass, Middle, Treble — EQ próprio do Clean |
| Overdrive 1 | Gain, Volume, Scoop |
| Overdrive 2 | Gain, Volume, Scoop |
| Overdrive Tone | Bass, Middle, Treble — EQ compartilhado por OD1 e OD2 |
| Master | Volume, Presence |

Os dois Scoop são independentes. Alterar o Scoop do OD1 não altera o OD2. O EQ do Clean é separado do EQ compartilhado dos canais Overdrive.

### Extensões experimentais ArtMS

A seção `ArtMS Model Lab` contém Power Sag, Cabinet Resonance e Cabinet Simulation. Esses itens são controles experimentais da modelagem ArtMS, não controles físicos originais do AVT150.

## Fluxo de áudio da versão 0.1

1. Importar um WAV DI pelo seletor de arquivos Android.
2. Escolher Clean, OD1 ou OD2.
3. Ajustar os knobs e as chaves na interface.
4. Pressionar `RENDER AMP`.
5. Ouvir o DI com `PLAY DI` ou o resultado com `PLAY AMP`.

O processamento acontece localmente no telefone. O arquivo renderizado é salvo no diretório privado do aplicativo e reproduzido pelo Qt Multimedia.

### Formatos de áudio

Entrada: WAV RIFF PCM 16/24/32-bit ou IEEE float 32-bit, mono ou estéreo, 8–192 kHz. Saída: WAV PCM 16-bit, mantendo sample rate e número de canais. Limite da prévia nesta versão: 128 MiB por arquivo.

Esta versão é **renderização offline**. Não existe entrada de guitarra ao vivo, callback de baixa latência ou motor dedicado em tempo real. Isso é intencional: primeiro queremos avaliar a modelagem e o timbre sem misturar esse teste com os problemas de áudio ao vivo.

## Modelo de amplificador

O AmpCore 0.1 contém:

- lookup table de saturação suave para estágios não lineares;
- caminhos diferentes de pré-amplificação Clean, OD1 e OD2;
- Bright no Clean;
- Scoop com contorno de médios independente em OD1 e OD2;
- EQ de três bandas separada para Clean e compartilhada para OD1/OD2;
- seção de potência com compressão dinâmica experimental (Power Sag);
- filtros de gabinete e ressonância ajustável;
- bloqueio de DC e limite de segurança na saída.

**Limite de fidelidade:** isto é um modelo comportamental inicial inspirado na arquitetura e nos controles do AVT150. Não é uma extração do circuito, não é modelagem componente a componente e ainda não foi calibrado por comparação auditiva com gravações DI e o amplificador físico. Os pontos de partida e a resposta tonal precisam ser ajustados após ouvir material real.

## Compilar e testar o núcleo C++ no computador

Requisitos: CMake 3.22+, Ninja ou Make e compilador C++20.

```bash
cmake -S . -B build -G Ninja -DARTMS_BUILD_TESTS=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build
ctest --test-dir build --output-on-failure
```

Os testes verificam os três caminhos de canal, ausência de NaN/Inf e round-trip de WAV.

## Compilar para Android

Requisitos:

- Qt 6.6 ou superior com módulos Core, Gui, Qml, Quick, Quick Controls 2, Multimedia e Concurrent;
- kit Qt para Android ARM64 (`arm64-v8a`);
- Android SDK, NDK e JDK nas versões compatíveis com a versão do Qt instalada.

Caminho recomendado:

1. Abrir este diretório no Qt Creator como projeto CMake.
2. Instalar/selecionar um kit Qt for Android ARM64.
3. Selecionar o dispositivo Android ou um emulador ARM64 compatível.
4. Compilar e executar o target `artms_amp_mobile`.

O `CMakeLists.txt` já aponta para `android/AndroidManifest.xml` e declara o identificador `org.artms.amplake`.

## Organização

```text
src/
  AmpSettings.h       Parâmetros e estado dos canais
  AmpCore.h/.cpp      Núcleo independente de DSP
  WavIO.h/.cpp        Leitor WAV e escritor PCM16
  AmpController.h/.cpp  Ponte Qt/QML e render offline em worker
qml/
  Main.qml            Interface móvel e transporte A/B
  Knob.qml             Knob circular reutilizável
android/
  AndroidManifest.xml
 tests/
  AmpCoreTests.cpp
 docs/
  MODELING_NOTES.md
```

## Próximas validações

1. Compilar no kit Android ARM64 e instalar no Galaxy S21 FE.
2. Verificar importação de WAV pelo seletor nativo Android e reprodução dos dois arquivos.
3. Ouvir DI/Clean/OD1/OD2 com o mesmo material e nível compensado.
4. Ajustar ganho, EQ e contornos a partir do teste auditivo.
5. Medir tempo de renderização, CPU e temperatura do Exynos 2100.
6. Somente depois avaliar entrada de guitarra ao vivo.

## Validação executada neste pacote

- Build do `artms_ampcore` com GCC 14.2 / C++20: OK.
- CTest: 1/1 passou.
- Build de testes com AddressSanitizer + UndefinedBehaviorSanitizer: OK; 1/1 passou.
- QML/Android APK: ainda não compilados neste ambiente (Qt 6 e SDK/NDK ausentes).
