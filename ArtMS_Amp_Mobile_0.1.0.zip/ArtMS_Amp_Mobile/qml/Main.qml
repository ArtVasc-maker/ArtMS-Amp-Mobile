import QtQuick
import QtQuick.Controls
import QtQuick.Controls.Material
import QtQuick.Layouts
import QtQuick.Dialogs
import QtMultimedia
import ArtMS.AmpMobile 1.0

ApplicationWindow {
    id: window
    visible: true
    width: 430
    height: 900
    minimumWidth: 340
    minimumHeight: 600
    title: "ArtMS Amp"
    color: "#0B1421"
    Material.theme: Material.Dark
    Material.accent: "#8FB9FF"

    property url selectedInputUrl
    property bool ampAudition: true

    AmpController { id: controller }

    FileDialog {
        id: wavPicker
        title: "Importar gravação DI"
        nameFilters: ["WAV audio (*.wav)", "All files (*)"]
        fileMode: FileDialog.OpenFile
        onAccepted: {
            window.selectedInputUrl = selectedFile
            controller.setInputUrl(selectedFile)
        }
    }

    MediaPlayer {
        id: audioPlayer
        audioOutput: AudioOutput { volume: 0.85 }
        onErrorOccurred: function(error, errorString) {
            console.warn("Falha na reprodução:", error, errorString)
        }
    }

    function playSource(url) {
        if (!url || url.toString().length === 0)
            return
        audioPlayer.stop()
        audioPlayer.source = url
        audioPlayer.play()
    }

    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#101D2D" }
            GradientStop { position: 0.55; color: "#0B1421" }
            GradientStop { position: 1.0; color: "#111C2A" }
        }
    }

    ScrollView {
        id: scroll
        anchors.fill: parent
        clip: true
        contentWidth: availableWidth

        Column {
            width: scroll.availableWidth
            height: implicitHeight
            spacing: 12

            Row {
                x: 15
                width: parent.width - 30
                height: 40
                spacing: 10
                Column {
                    width: parent.width - 80
                    spacing: 2
                    Text {
                        text: "ArtMS <font color='#8FB9FF'>AMP</font>"
                        textFormat: Text.RichText
                        color: "#F3F6FB"
                        font.pixelSize: 27
                        font.weight: Font.Black
                    }
                    Text {
                        text: "VALVESTATE 2000 · AVT150 INSPIRED"
                        color: "#8FA3BA"
                        font.pixelSize: 10
                        font.letterSpacing: 1.1
                    }
                }
                Rectangle {
                    width: 68
                    height: 32
                    radius: 16
                    color: "#183A35"
                    border.color: "#2F806A"
                    Text {
                        anchors.centerIn: parent
                        text: "LOCAL"
                        color: "#91E0C2"
                        font.pixelSize: 10
                        font.bold: true
                    }
                }
            }

            Rectangle {
                x: 15
                width: parent.width - 30
                height: 46
                radius: 13
                color: "#14263A"
                border.color: "#263F5B"
                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 13
                    anchors.rightMargin: 13
                    spacing: 8
                    Rectangle { width: 7; height: 7; radius: 4; color: controller.busy ? "#E8B66D" : "#70D6A9" }
                    Text {
                        Layout.fillWidth: true
                        text: controller.status
                        color: "#B7C8DC"
                        font.pixelSize: 11
                        elide: Text.ElideRight
                    }
                    Text { text: "WAV → AMP"; color: "#7390B2"; font.pixelSize: 9; font.bold: true }
                }
            }

            // CLEAN CHANNEL
            Rectangle {
                x: 15
                width: parent.width - 30
                radius: 17
                color: "#152438"
                border.color: controller.channel === "CLEAN" ? "#668BBB" : "#2A3A4E"
                border.width: controller.channel === "CLEAN" ? 1.5 : 1
                height: cleanContent.implicitHeight + 24
                Column {
                    id: cleanContent
                    x: 12; y: 12
                    width: parent.width - 24
                    spacing: 8
                    RowLayout {
                        width: parent.width
                        height: 40
                        Text { text: "01  CLEAN"; color: "#F0F4FA"; font.pixelSize: 15; font.bold: true; Layout.fillWidth: true }
                        Button {
                            text: controller.channel === "CLEAN" ? "SELECTED" : "SELECT"
                            flat: true
                            onClicked: controller.setChannel("CLEAN")
                        }
                    }
                    Text { text: "PREAMP"; color: "#829BB8"; font.pixelSize: 9; font.bold: true; font.letterSpacing: 1 }
                    Row {
                        width: parent.width
                        height: 116
                        spacing: width - 180
                        Knob { label: "GAIN"; value: controller.parameters.cleanGain; onValueEdited: controller.setParameter("cleanGain", newValue) }
                        Knob { label: "VOLUME"; value: controller.parameters.cleanVolume; onValueEdited: controller.setParameter("cleanVolume", newValue) }
                    }
                    RowLayout {
                        width: parent.width
                        height: 42
                        Text { text: "BRIGHT"; color: "#C0CDDD"; font.pixelSize: 11; font.bold: true; Layout.fillWidth: true }
                        Switch {
                            checked: controller.parameters.cleanBright
                            onToggled: controller.setToggle("cleanBright", checked)
                        }
                    }
                    Rectangle { width: parent.width; height: 1; color: "#2B4058" }
                    Text { text: "CLEAN TONE · PASSIVE 3-BAND EQ"; color: "#829BB8"; font.pixelSize: 9; font.bold: true; font.letterSpacing: 0.6 }
                    Row {
                        width: parent.width
                        height: 116
                        spacing: (width - 270) / 2
                        Knob { label: "BASS"; value: controller.parameters.cleanBass; onValueEdited: controller.setParameter("cleanBass", newValue) }
                        Knob { label: "MIDDLE"; value: controller.parameters.cleanMiddle; onValueEdited: controller.setParameter("cleanMiddle", newValue) }
                        Knob { label: "TREBLE"; value: controller.parameters.cleanTreble; onValueEdited: controller.setParameter("cleanTreble", newValue) }
                    }
                }
            }

            // OD1
            Rectangle {
                x: 15
                width: parent.width - 30
                radius: 17
                color: "#152438"
                border.color: controller.channel === "OD1" ? "#C18A58" : "#2A3A4E"
                border.width: controller.channel === "OD1" ? 1.5 : 1
                height: od1Content.implicitHeight + 24
                Column {
                    id: od1Content
                    x: 12; y: 12; width: parent.width - 24; spacing: 8
                    RowLayout {
                        width: parent.width
                        height: 40
                        Text { text: "02  OVERDRIVE 1"; color: "#F0F4FA"; font.pixelSize: 15; font.bold: true; Layout.fillWidth: true }
                        Button { text: controller.channel === "OD1" ? "SELECTED" : "SELECT"; flat: true; onClicked: controller.setChannel("OD1") }
                    }
                    Text { text: "OPEN · ARTICULATED CRUNCH"; color: "#C59A72"; font.pixelSize: 9; font.bold: true; font.letterSpacing: 0.7 }
                    Row {
                        width: parent.width
                        height: 116
                        spacing: width - 180
                        Knob { label: "GAIN"; value: controller.parameters.od1Gain; accent: "#E4AD75"; onValueEdited: controller.setParameter("od1Gain", newValue) }
                        Knob { label: "VOLUME"; value: controller.parameters.od1Volume; accent: "#E4AD75"; onValueEdited: controller.setParameter("od1Volume", newValue) }
                    }
                    RowLayout {
                        width: parent.width
                        height: 42
                        Text { text: "SCOOP · MID CONTOUR"; color: "#C0CDDD"; font.pixelSize: 11; font.bold: true; Layout.fillWidth: true }
                        Switch { checked: controller.parameters.od1Scoop; onToggled: controller.setToggle("od1Scoop", checked) }
                    }
                }
            }

            // OD2
            Rectangle {
                x: 15
                width: parent.width - 30
                radius: 17
                color: "#152438"
                border.color: controller.channel === "OD2" ? "#C18A58" : "#2A3A4E"
                border.width: controller.channel === "OD2" ? 1.5 : 1
                height: od2Content.implicitHeight + 24
                Column {
                    id: od2Content
                    x: 12; y: 12; width: parent.width - 24; spacing: 8
                    RowLayout {
                        width: parent.width
                        height: 40
                        Text { text: "03  OVERDRIVE 2"; color: "#F0F4FA"; font.pixelSize: 15; font.bold: true; Layout.fillWidth: true }
                        Button { text: controller.channel === "OD2" ? "SELECTED" : "SELECT"; flat: true; onClicked: controller.setChannel("OD2") }
                    }
                    Text { text: "HIGH GAIN · DENSE & COMPRESSED"; color: "#C59A72"; font.pixelSize: 9; font.bold: true; font.letterSpacing: 0.7 }
                    Row {
                        width: parent.width
                        height: 116
                        spacing: width - 180
                        Knob { label: "GAIN"; value: controller.parameters.od2Gain; accent: "#E4AD75"; onValueEdited: controller.setParameter("od2Gain", newValue) }
                        Knob { label: "VOLUME"; value: controller.parameters.od2Volume; accent: "#E4AD75"; onValueEdited: controller.setParameter("od2Volume", newValue) }
                    }
                    RowLayout {
                        width: parent.width
                        height: 42
                        Text { text: "SCOOP · FAT-BOTTOM CONTOUR"; color: "#C0CDDD"; font.pixelSize: 11; font.bold: true; Layout.fillWidth: true }
                        Switch { checked: controller.parameters.od2Scoop; onToggled: controller.setToggle("od2Scoop", checked) }
                    }
                }
            }

            // OD EQ
            Rectangle {
                x: 15
                width: parent.width - 30
                radius: 17
                color: "#18283B"
                border.color: "#3C526C"
                height: odEqContent.implicitHeight + 24
                Column {
                    id: odEqContent
                    x: 12; y: 12; width: parent.width - 24; spacing: 8
                    Text { text: "04  OVERDRIVE TONE"; color: "#F0F4FA"; font.pixelSize: 15; font.bold: true }
                    Text { text: "SHARED EQ · OD1 + OD2"; color: "#829BB8"; font.pixelSize: 9; font.bold: true; font.letterSpacing: 0.7 }
                    Row {
                        width: parent.width
                        height: 116
                        spacing: (width - 270) / 2
                        Knob { label: "BASS"; value: controller.parameters.odBass; onValueEdited: controller.setParameter("odBass", newValue) }
                        Knob { label: "MIDDLE"; value: controller.parameters.odMiddle; onValueEdited: controller.setParameter("odMiddle", newValue) }
                        Knob { label: "TREBLE"; value: controller.parameters.odTreble; onValueEdited: controller.setParameter("odTreble", newValue) }
                    }
                }
            }

            // MASTER
            Rectangle {
                x: 15
                width: parent.width - 30
                radius: 17
                color: "#152438"
                border.color: "#2A3A4E"
                height: masterContent.implicitHeight + 24
                Column {
                    id: masterContent
                    x: 12; y: 12; width: parent.width - 24; spacing: 8
                    Text { text: "05  MASTER"; color: "#F0F4FA"; font.pixelSize: 15; font.bold: true }
                    Row {
                        width: parent.width
                        height: 116
                        spacing: width - 180
                        Knob { label: "MASTER"; value: controller.parameters.masterVolume; accent: "#8FB9FF"; onValueEdited: controller.setParameter("masterVolume", newValue) }
                        Knob { label: "PRESENCE"; value: controller.parameters.presence; accent: "#8FB9FF"; onValueEdited: controller.setParameter("presence", newValue) }
                    }
                }
            }

            // Experimental ArtMS extensions; deliberately separate from the AVT150 panel controls.
            Rectangle {
                x: 15
                width: parent.width - 30
                radius: 17
                color: "#102337"
                border.color: "#31506B"
                height: modelContent.implicitHeight + 24
                Column {
                    id: modelContent
                    x: 12; y: 12; width: parent.width - 24; spacing: 8
                    Text { text: "06  ARTMS MODEL LAB"; color: "#D4E4F8"; font.pixelSize: 14; font.bold: true }
                    Text { text: "EXPERIMENTAL · NOT ORIGINAL AVT150 CONTROLS"; color: "#7FA0C2"; font.pixelSize: 9; font.bold: true; font.letterSpacing: 0.4 }
                    Row {
                        width: parent.width
                        height: 116
                        spacing: (width - 180)
                        Knob { label: "POWER SAG"; value: controller.parameters.powerSag; accent: "#7FD5C1"; onValueEdited: controller.setParameter("powerSag", newValue) }
                        Knob { label: "CAB RESO"; value: controller.parameters.cabinetResonance; accent: "#7FD5C1"; onValueEdited: controller.setParameter("cabinetResonance", newValue) }
                    }
                    RowLayout {
                        width: parent.width
                        height: 42
                        Text { text: "CABINET SIMULATION"; color: "#C0CDDD"; font.pixelSize: 11; font.bold: true; Layout.fillWidth: true }
                        Switch { checked: controller.parameters.cabinetEnabled; onToggled: controller.setToggle("cabinetEnabled", checked) }
                    }
                }
            }

            Rectangle { x: 15; width: parent.width - 30; height: 1; color: "#2D4057" }

            Text { x: 15; text: "AUDIO TEST"; color: "#9AB0CA"; font.pixelSize: 10; font.bold: true; font.letterSpacing: 1.2 }
            Rectangle {
                x: 15
                width: parent.width - 30
                radius: 15
                color: "#13243A"
                border.color: "#2A4564"
                height: 170
                Column {
                    anchors.fill: parent
                    anchors.margins: 12
                    spacing: 9
                    RowLayout {
                        width: parent.width
                        height: 40
                        Text { Layout.fillWidth: true; text: controller.hasInput ? controller.inputName : "Nenhum WAV DI importado"; color: "#D4DEEA"; font.pixelSize: 11; elide: Text.ElideMiddle }
                        Button { text: "IMPORT WAV"; onClicked: wavPicker.open() }
                    }
                    RowLayout {
                        width: parent.width
                        height: 40
                        Button { text: "RENDER AMP"; highlighted: true; enabled: controller.hasInput && !controller.busy; onClicked: controller.processInput(); Layout.fillWidth: true }
                        Button { text: "STOP"; enabled: audioPlayer.playbackState === MediaPlayer.PlayingState; onClicked: audioPlayer.stop() }
                    }
                    RowLayout {
                        width: parent.width
                        height: 40
                        Button { text: "PLAY DI"; enabled: controller.hasInput; onClicked: window.playSource(window.selectedInputUrl); Layout.fillWidth: true }
                        Button { text: "PLAY AMP"; enabled: controller.hasOutput; onClicked: window.playSource(controller.outputUrl); Layout.fillWidth: true }
                    }
                }
            }

            Text {
                x: 15
                width: parent.width - 30
                text: "AmpCore 0.1 · processamento offline por WAV · modelo experimental inspirado no AVT150. Ainda não é áudio ao vivo nem reprodução fiel de circuito."
                color: "#758BA5"
                font.pixelSize: 10
                wrapMode: Text.WordWrap
                horizontalAlignment: Text.AlignHCenter
            }
            Item { width: 1; height: 8 }
        }
    }
}
