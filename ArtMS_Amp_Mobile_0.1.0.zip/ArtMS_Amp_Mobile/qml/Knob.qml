import QtQuick
import QtQuick.Controls

Item {
    id: root
    property string label: "CONTROL"
    property real value: 5.0
    property color accent: "#8FB9FF"
    property string suffix: ""
    signal valueEdited(real newValue)

    width: 90
    height: 116
    implicitWidth: 90
    implicitHeight: 116

    Column {
        anchors.fill: parent
        spacing: 3
        Text {
            width: parent.width
            text: root.label
            color: "#B7C5D8"
            font.pixelSize: 10
            font.weight: Font.DemiBold
            horizontalAlignment: Text.AlignHCenter
            elide: Text.ElideRight
        }

        Item {
            width: 76
            height: 76
            anchors.horizontalCenter: parent.horizontalCenter

            Dial {
                id: dial
                anchors.fill: parent
                from: 0
                to: 10
                stepSize: 0.1
                value: root.value
                startAngle: 135
                endAngle: 405
                inputMode: Dial.Vertical
                onMoved: root.valueEdited(value)

                background: Item {
                    Canvas {
                        id: ring
                        anchors.fill: parent
                        onPaint: {
                            const ctx = getContext("2d")
                            ctx.clearRect(0, 0, width, height)
                            const cx = width / 2
                            const cy = height / 2
                            const radius = Math.min(width, height) * 0.37
                            ctx.lineWidth = 5
                            ctx.lineCap = "round"
                            ctx.strokeStyle = "#2B3A4E"
                            ctx.beginPath()
                            ctx.arc(cx, cy, radius, 45 * Math.PI / 180, 315 * Math.PI / 180, false)
                            ctx.stroke()
                            ctx.strokeStyle = root.accent
                            ctx.beginPath()
                            ctx.arc(cx, cy, radius, 45 * Math.PI / 180,
                                    (45 + 270 * dial.position) * Math.PI / 180, false)
                            ctx.stroke()
                        }
                        Connections {
                            target: dial
                            function onPositionChanged() { ring.requestPaint() }
                        }
                    }
                    Rectangle {
                        anchors.centerIn: parent
                        width: 48
                        height: 48
                        radius: 24
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: "#33465D" }
                            GradientStop { position: 1.0; color: "#172638" }
                        }
                        border.color: "#50657D"
                        border.width: 1
                    }
                }

                handle: Rectangle {
                    width: 7
                    height: 7
                    radius: 4
                    color: "#F4F7FC"
                    x: dial.background.width / 2 - width / 2
                    y: dial.background.height / 2 - height / 2
                    transform: [
                        Translate { y: -Math.min(dial.background.width, dial.background.height) * 0.32 },
                        Rotation { angle: dial.angle; origin.x: 3.5; origin.y: 3.5 }
                    ]
                }
            }
        }

        Text {
            width: parent.width
            text: Number(root.value).toFixed(1) + root.suffix
            color: "#F0F4FA"
            font.pixelSize: 12
            font.weight: Font.Bold
            horizontalAlignment: Text.AlignHCenter
        }
    }
}
