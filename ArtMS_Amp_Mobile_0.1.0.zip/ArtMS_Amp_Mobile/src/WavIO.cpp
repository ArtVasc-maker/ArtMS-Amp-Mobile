#include "WavIO.h"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <cstring>
#include <limits>

namespace artms {
namespace {
std::uint16_t u16(const unsigned char* p) { return static_cast<std::uint16_t>(p[0] | (p[1] << 8)); }
std::uint32_t u32(const unsigned char* p) { return static_cast<std::uint32_t>(p[0]) | (static_cast<std::uint32_t>(p[1]) << 8) | (static_cast<std::uint32_t>(p[2]) << 16) | (static_cast<std::uint32_t>(p[3]) << 24); }
void put16(std::ofstream& f, std::uint16_t v) { const char b[2]{static_cast<char>(v & 0xff), static_cast<char>((v >> 8) & 0xff)}; f.write(b, 2); }
void put32(std::ofstream& f, std::uint32_t v) { const char b[4]{static_cast<char>(v & 0xff), static_cast<char>((v >> 8) & 0xff), static_cast<char>((v >> 16) & 0xff), static_cast<char>((v >> 24) & 0xff)}; f.write(b, 4); }
}

bool readWavMemory(const unsigned char* bytes, std::size_t byteCount, AudioFile& audio, std::string& error) {
    if (!bytes || byteCount < 44 || std::string(reinterpret_cast<const char*>(bytes), 4) != "RIFF" ||
        std::string(reinterpret_cast<const char*>(bytes + 8), 4) != "WAVE") {
        error = "O arquivo não é um WAV RIFF válido."; return false;
    }

    std::uint16_t format = 0, channels = 0, bits = 0;
    std::uint32_t sampleRate = 0, dataOffset = 0, dataSize = 0;
    bool haveFmt = false, haveData = false;
    std::size_t pos = 12;
    while (pos + 8 <= byteCount) {
        const std::string id(reinterpret_cast<const char*>(bytes + pos), 4);
        const std::uint32_t chunkSize = u32(bytes + pos + 4);
        const std::size_t chunkStart = pos + 8;
        if (chunkStart + chunkSize > byteCount) { error = "Chunk WAV incompleto."; return false; }
        if (id == "fmt ") {
            if (chunkSize < 16) { error = "Cabeçalho fmt inválido."; return false; }
            format = u16(bytes + chunkStart);
            channels = u16(bytes + chunkStart + 2);
            sampleRate = u32(bytes + chunkStart + 4);
            bits = u16(bytes + chunkStart + 14);
            if (format == 0xFFFE && chunkSize >= 40) format = u16(bytes + chunkStart + 24);
            haveFmt = true;
        } else if (id == "data") {
            if (chunkStart > std::numeric_limits<std::uint32_t>::max()) { error = "WAV grande demais."; return false; }
            dataOffset = static_cast<std::uint32_t>(chunkStart);
            dataSize = chunkSize;
            haveData = true;
        }
        pos = chunkStart + chunkSize + (chunkSize & 1U);
    }

    if (!haveFmt || !haveData || (format != 1 && format != 3) ||
        (channels != 1 && channels != 2) || sampleRate < 8000 || sampleRate > 192000 ||
        !((format == 1 && (bits == 16 || bits == 24 || bits == 32)) || (format == 3 && bits == 32))) {
        error = "Formato não suportado. Use WAV PCM 16/24/32-bit ou float 32-bit, mono/estéreo, 8–192 kHz.";
        return false;
    }

    const std::size_t bytesPerSample = bits / 8;
    const std::size_t frameBytes = bytesPerSample * channels;
    if (frameBytes == 0 || dataSize < frameBytes) { error = "O WAV não contém áudio válido."; return false; }
    const std::size_t sampleCount = (dataSize / frameBytes) * static_cast<std::size_t>(channels);
    if (sampleCount > 100000000ULL) { error = "O arquivo é grande demais para esta prévia."; return false; }
    audio.sampleRate = static_cast<int>(sampleRate);
    audio.channels = static_cast<int>(channels);
    audio.samples.resize(sampleCount);

    const unsigned char* audioData = bytes + dataOffset;
    for (std::size_t i = 0; i < sampleCount; ++i) {
        const unsigned char* p = audioData + i * bytesPerSample;
        float value = 0.0f;
        if (format == 3) {
            const std::uint32_t raw = u32(p);
            std::memcpy(&value, &raw, sizeof(value));
        } else if (bits == 16) {
            const auto raw = static_cast<std::int16_t>(u16(p));
            value = static_cast<float>(raw) / 32768.0f;
        } else if (bits == 24) {
            std::int32_t raw = static_cast<std::int32_t>(p[0] | (p[1] << 8) | (p[2] << 16));
            if (raw & 0x800000) raw |= ~0xFFFFFF;
            value = static_cast<float>(raw) / 8388608.0f;
        } else {
            const auto raw = static_cast<std::int32_t>(u32(p));
            value = static_cast<float>(static_cast<double>(raw) / 2147483648.0);
        }
        audio.samples[i] = std::isfinite(value) ? std::clamp(value, -4.0f, 4.0f) : 0.0f;
    }
    return true;
}

bool readWav(const std::string& path, AudioFile& audio, std::string& error) {
    std::ifstream file(path, std::ios::binary);
    if (!file) { error = "Não foi possível abrir o WAV de entrada."; return false; }
    file.seekg(0, std::ios::end);
    const auto length = file.tellg();
    if (length < 44) { error = "Arquivo WAV muito pequeno ou inválido."; return false; }
    file.seekg(0, std::ios::beg);
    std::vector<unsigned char> bytes(static_cast<std::size_t>(length));
    file.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    if (!file) { error = "Falha ao ler o arquivo WAV."; return false; }
    return readWavMemory(bytes.data(), bytes.size(), audio, error);
}

bool writeWav16(const std::string& path, const AudioFile& audio, std::string& error) {
    if ((audio.channels != 1 && audio.channels != 2) || audio.sampleRate < 8000 || audio.samples.empty()) {
        error = "Áudio de saída inválido."; return false;
    }
    const std::uint64_t dataSize64 = audio.samples.size() * 2ULL;
    if (dataSize64 > std::numeric_limits<std::uint32_t>::max() - 36ULL) { error = "WAV de saída excede o limite RIFF."; return false; }
    const auto dataSize = static_cast<std::uint32_t>(dataSize64);
    std::ofstream file(path, std::ios::binary);
    if (!file) { error = "Não foi possível criar o WAV de saída."; return false; }
    file.write("RIFF", 4); put32(file, 36U + dataSize); file.write("WAVE", 4);
    file.write("fmt ", 4); put32(file, 16); put16(file, 1); put16(file, static_cast<std::uint16_t>(audio.channels));
    put32(file, static_cast<std::uint32_t>(audio.sampleRate));
    put32(file, static_cast<std::uint32_t>(audio.sampleRate * audio.channels * 2));
    put16(file, static_cast<std::uint16_t>(audio.channels * 2)); put16(file, 16);
    file.write("data", 4); put32(file, dataSize);
    for (float sample : audio.samples) {
        const float safe = std::isfinite(sample) ? std::clamp(sample, -1.0f, 1.0f) : 0.0f;
        const auto value = static_cast<std::int16_t>(std::lrint(safe * (safe < 0.0f ? 32768.0f : 32767.0f)));
        put16(file, static_cast<std::uint16_t>(value));
    }
    if (!file) { error = "Falha ao gravar o WAV de saída."; return false; }
    return true;
}

} // namespace artms
