#pragma once

#include <algorithm>
#include <string>

namespace artms {

enum class Channel { Clean, OD1, OD2 };

struct AmpSettings {
    Channel channel = Channel::Clean;

    // Marshall AVT150-style channel controls (0..10).
    float cleanGain = 2.5f;
    float cleanVolume = 5.0f;
    bool cleanBright = false;
    float cleanBass = 5.0f;
    float cleanMiddle = 5.0f;
    float cleanTreble = 5.0f;

    float od1Gain = 4.5f;
    float od1Volume = 5.0f;
    bool od1Scoop = false;

    float od2Gain = 6.5f;
    float od2Volume = 5.0f;
    bool od2Scoop = false;

    // Shared by OD1 and OD2, as on the AVT150.
    float odBass = 5.0f;
    float odMiddle = 5.0f;
    float odTreble = 5.0f;

    float masterVolume = 5.0f;
    float presence = 5.0f;

    // Experimental model controls; not physical AVT150 front-panel controls.
    float powerSag = 3.0f;
    float cabinetResonance = 5.0f;
    bool cabinetEnabled = true;
};

inline float clampControl(float value) noexcept {
    return std::clamp(value, 0.0f, 10.0f);
}

} // namespace artms
