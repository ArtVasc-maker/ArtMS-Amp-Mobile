#include "AmpController.h"
#include "AmpCore.h"
#include "WavIO.h"

#include <QDateTime>
#include <QFile>
#include <QDir>
#include <QFileInfo>
#include <QStandardPaths>
#include <QUrl>
#include <QtConcurrent/QtConcurrentRun>
#include <algorithm>
#include <string>

namespace artms {

AmpController::AmpController(QObject* parent) : QObject(parent) {
    refreshMap();
    connect(&m_watcher, &QFutureWatcher<JobResult>::finished, this, [this]() {
        const JobResult result = m_watcher.result();
        setBusy(false);
        if (result.ok) {
            m_outputUrl = QUrl::fromLocalFile(result.path);
            emit outputChanged();
            setStatus(result.message);
        } else {
            setStatus(result.message);
        }
    });
}

void AmpController::refreshMap() {
    m_parameters = {
        {"cleanGain", m_settings.cleanGain}, {"cleanVolume", m_settings.cleanVolume},
        {"cleanBright", m_settings.cleanBright}, {"cleanBass", m_settings.cleanBass},
        {"cleanMiddle", m_settings.cleanMiddle}, {"cleanTreble", m_settings.cleanTreble},
        {"od1Gain", m_settings.od1Gain}, {"od1Volume", m_settings.od1Volume},
        {"od1Scoop", m_settings.od1Scoop}, {"od2Gain", m_settings.od2Gain},
        {"od2Volume", m_settings.od2Volume}, {"od2Scoop", m_settings.od2Scoop},
        {"odBass", m_settings.odBass}, {"odMiddle", m_settings.odMiddle},
        {"odTreble", m_settings.odTreble}, {"masterVolume", m_settings.masterVolume},
        {"presence", m_settings.presence}, {"powerSag", m_settings.powerSag},
        {"cabinetResonance", m_settings.cabinetResonance},
        {"cabinetEnabled", m_settings.cabinetEnabled}
    };
    emit parametersChanged();
}

void AmpController::setStatus(const QString& value) {
    if (m_status == value) return;
    m_status = value;
    emit statusChanged();
}

void AmpController::setBusy(bool value) {
    if (m_busy == value) return;
    m_busy = value;
    emit busyChanged();
}

void AmpController::setInputUrl(const QUrl& url) {
    if (!url.isValid()) return;
    m_inputUrl = url;
    QString local = url.isLocalFile() ? url.toLocalFile() : url.toString();
    m_inputName = QFileInfo(local).fileName();
    if (m_inputName.isEmpty()) m_inputName = QStringLiteral("WAV selecionado");
    emit inputChanged();
    setStatus(QStringLiteral("DI carregado: %1").arg(m_inputName));
}

void AmpController::setChannel(const QString& requested) {
    const QString c = requested.trimmed().toUpper();
    if (c == QStringLiteral("CLEAN")) m_settings.channel = Channel::Clean;
    else if (c == QStringLiteral("OD1")) m_settings.channel = Channel::OD1;
    else if (c == QStringLiteral("OD2")) m_settings.channel = Channel::OD2;
    else return;
    if (m_channel != c) { m_channel = c; emit channelChanged(); }
}

void AmpController::setParameter(const QString& name, double value) {
    const float v = clampControl(static_cast<float>(value));
    const auto key = name.toStdString();
    if (key == "cleanGain") m_settings.cleanGain = v;
    else if (key == "cleanVolume") m_settings.cleanVolume = v;
    else if (key == "cleanBass") m_settings.cleanBass = v;
    else if (key == "cleanMiddle") m_settings.cleanMiddle = v;
    else if (key == "cleanTreble") m_settings.cleanTreble = v;
    else if (key == "od1Gain") m_settings.od1Gain = v;
    else if (key == "od1Volume") m_settings.od1Volume = v;
    else if (key == "od2Gain") m_settings.od2Gain = v;
    else if (key == "od2Volume") m_settings.od2Volume = v;
    else if (key == "odBass") m_settings.odBass = v;
    else if (key == "odMiddle") m_settings.odMiddle = v;
    else if (key == "odTreble") m_settings.odTreble = v;
    else if (key == "masterVolume") m_settings.masterVolume = v;
    else if (key == "presence") m_settings.presence = v;
    else if (key == "powerSag") m_settings.powerSag = v;
    else if (key == "cabinetResonance") m_settings.cabinetResonance = v;
    else return;
    m_parameters.insert(name, v);
    emit parametersChanged();
}

void AmpController::setToggle(const QString& name, bool value) {
    if (name == QStringLiteral("cleanBright")) m_settings.cleanBright = value;
    else if (name == QStringLiteral("od1Scoop")) m_settings.od1Scoop = value;
    else if (name == QStringLiteral("od2Scoop")) m_settings.od2Scoop = value;
    else if (name == QStringLiteral("cabinetEnabled")) m_settings.cabinetEnabled = value;
    else return;
    m_parameters.insert(name, value);
    emit parametersChanged();
}

void AmpController::clearOutput() {
    m_outputUrl = QUrl();
    emit outputChanged();
}

void AmpController::processInput() {
    if (m_busy) return;
    if (!m_inputUrl.isValid()) { setStatus(QStringLiteral("Primeiro importe um arquivo WAV DI.")); return; }

    const QString inputPath = m_inputUrl.isLocalFile() ? m_inputUrl.toLocalFile() : m_inputUrl.toString();
    const QString base = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    if (base.isEmpty()) { setStatus(QStringLiteral("Não foi possível localizar o armazenamento do aplicativo.")); return; }
    QDir().mkpath(base);
    const QString outputPath = QDir(base).filePath(QStringLiteral("ArtMS_Amp_%1.wav").arg(QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss_zzz")));
    const AmpSettings settings = m_settings;
    setBusy(true);
    setStatus(QStringLiteral("Processando WAV com AmpCore C++20…"));

    m_watcher.setFuture(QtConcurrent::run([inputPath, outputPath, settings]() -> JobResult {
        AudioFile audio;
        std::string error;
        QFile sourceFile(inputPath);
        if (!sourceFile.open(QIODevice::ReadOnly))
            return {false, QStringLiteral("Não foi possível abrir o WAV escolhido no Android."), {}};
        if (sourceFile.size() > 128LL * 1024LL * 1024LL)
            return {false, QStringLiteral("Para esta prévia, limite a gravação DI a 128 MiB."), {}};
        const QByteArray wavBytes = sourceFile.readAll();
        sourceFile.close();
        if (wavBytes.size() > 128LL * 1024LL * 1024LL)
            return {false, QStringLiteral("Para esta prévia, limite a gravação DI a 128 MiB."), {}};
        if (wavBytes.isEmpty() || !readWavMemory(
                reinterpret_cast<const unsigned char*>(wavBytes.constData()),
                static_cast<std::size_t>(wavBytes.size()), audio, error))
            return {false, error.empty() ? QStringLiteral("WAV vazio ou inacessível.") : QString::fromStdString(error), {}};
        if (audio.samples.empty()) return {false, QStringLiteral("O WAV está vazio."), {}};
        AmpCore core;
        core.reset();
        core.process(audio.samples, audio.channels, audio.sampleRate, settings);
        if (!writeWav16(outputPath.toStdString(), audio, error))
            return {false, QString::fromStdString(error), {}};
        const double seconds = static_cast<double>(audio.samples.size()) /
                               (static_cast<double>(audio.channels) * audio.sampleRate);
        return {true, QStringLiteral("Render concluído · %1 s de áudio · %2").arg(seconds, 0, 'f', 2)
                            .arg(settings.channel == Channel::Clean ? QStringLiteral("CLEAN") :
                                 settings.channel == Channel::OD1 ? QStringLiteral("OD1") : QStringLiteral("OD2")),
                outputPath};
    }));
}

} // namespace artms
