#pragma once

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>

namespace artms {

struct AudioFile {
    int sampleRate = 0;
    int channels = 0;
    std::vector<float> samples;
};

bool readWav(const std::string& path, AudioFile& audio, std::string& error);
bool readWavMemory(const unsigned char* data, std::size_t size, AudioFile& audio, std::string& error);
bool writeWav16(const std::string& path, const AudioFile& audio, std::string& error);

} // namespace artms
