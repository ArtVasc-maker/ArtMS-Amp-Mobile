#include "AmpController.h"

#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QtQml>

int main(int argc, char *argv[]) {
    QGuiApplication app(argc, argv);
    QCoreApplication::setOrganizationName(QStringLiteral("ArtMS"));
    QCoreApplication::setApplicationName(QStringLiteral("ArtMS Amp"));

    qmlRegisterType<artms::AmpController>("ArtMS.AmpMobile", 1, 0, "AmpController");

    QQmlApplicationEngine engine;
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
                     &app, []() { QCoreApplication::exit(EXIT_FAILURE); }, Qt::QueuedConnection);
    engine.loadFromModule("ArtMS.AmpMobile", "Main");
    return app.exec();
}
