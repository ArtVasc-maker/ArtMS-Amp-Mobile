#include "AmpCore.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>

namespace artms {
namespace {
constexpr float kPi = 3.14159265358979323846f;
constexpr float kMinSampleRate = 8000.0f;
constexpr float kMaxSampleRate = 192000.0f;

float safeFrequency(float frequency, float sampleRate) noexcept {
    return std::clamp(frequency, 10.0f, sampleRate * 0.45f);
}

void normalizeBiquad(float& b0, float& b1, float& b2,
                     float& a0, float& a1, float& a2) noexcept {
    if (std::abs(a0) < 1.0e-12f) {
        b0 = 1.0f; b1 = b2 = a1 = a2 = 0.0f; return;
    }
    b0 /= a0; b1 /= a0; b2 /= a0; a1 /= a0; a2 /= a0;
}

float controlToDb(float value) noexcept {
    // 5 is neutral; the response is deliberately broad but bounded.
    return (value - 5.0f) * 1.65f;
}
}

AmpCore::AmpCore() : m_lut(LutSize) {
    for (int i = 0; i < LutSize; ++i) {
        const float x = -8.0f + 16.0f * static_cast<float>(i) / static_cast<float>(LutSize - 1);
        m_lut[static_cast<std::size_t>(i)] = std::tanh(x);
    }
    reset();
}

void AmpCore::reset() noexcept {
    for (auto& s : m_state) s = ChannelState{};
}

float AmpCore::Biquad::run(float x) noexcept {
    const float y = b0 * x + z1;
    z1 = b1 * x - a1 * y + z2;
    z2 = b2 * x - a2 * y;
    if (!std::isfinite(y) || !std::isfinite(z1) || !std::isfinite(z2)) {
        z1 = z2 = 0.0f;
        return 0.0f;
    }
    return y;
}

void AmpCore::Biquad::setLowShelf(float sr, float frequency, float gainDb) noexcept {
    const float A = std::pow(10.0f, gainDb / 40.0f);
    const float w0 = 2.0f * kPi * safeFrequency(frequency, sr) / sr;
    const float c = std::cos(w0), s = std::sin(w0);
    const float alpha = s / 2.0f * std::sqrt(2.0f);
    const float beta = 2.0f * std::sqrt(A) * alpha;
    float b0 = A * ((A + 1.0f) - (A - 1.0f) * c + beta);
    float b1 = 2.0f * A * ((A - 1.0f) - (A + 1.0f) * c);
    float b2 = A * ((A + 1.0f) - (A - 1.0f) * c - beta);
    float a0 = (A + 1.0f) + (A - 1.0f) * c + beta;
    float a1 = -2.0f * ((A - 1.0f) + (A + 1.0f) * c);
    float a2 = (A + 1.0f) + (A - 1.0f) * c - beta;
    normalizeBiquad(b0,b1,b2,a0,a1,a2); this->b0=b0; this->b1=b1; this->b2=b2; this->a1=a1; this->a2=a2;
}

void AmpCore::Biquad::setHighShelf(float sr, float frequency, float gainDb) noexcept {
    const float A = std::pow(10.0f, gainDb / 40.0f);
    const float w0 = 2.0f * kPi * safeFrequency(frequency, sr) / sr;
    const float c = std::cos(w0), s = std::sin(w0);
    const float alpha = s / 2.0f * std::sqrt(2.0f);
    const float beta = 2.0f * std::sqrt(A) * alpha;
    float b0 = A * ((A + 1.0f) + (A - 1.0f) * c + beta);
    float b1 = -2.0f * A * ((A - 1.0f) + (A + 1.0f) * c);
    float b2 = A * ((A + 1.0f) + (A - 1.0f) * c - beta);
    float a0 = (A + 1.0f) - (A - 1.0f) * c + beta;
    float a1 = 2.0f * ((A - 1.0f) - (A + 1.0f) * c);
    float a2 = (A + 1.0f) - (A - 1.0f) * c - beta;
    normalizeBiquad(b0,b1,b2,a0,a1,a2); this->b0=b0; this->b1=b1; this->b2=b2; this->a1=a1; this->a2=a2;
}

void AmpCore::Biquad::setPeak(float sr, float frequency, float q, float gainDb) noexcept {
    const float A = std::pow(10.0f, gainDb / 40.0f);
    const float w0 = 2.0f * kPi * safeFrequency(frequency, sr) / sr;
    const float alpha = std::sin(w0) / (2.0f * std::max(0.1f, q));
    const float c = std::cos(w0);
    float b0 = 1.0f + alpha * A, b1 = -2.0f * c, b2 = 1.0f - alpha * A;
    float a0 = 1.0f + alpha / A, a1 = -2.0f * c, a2 = 1.0f - alpha / A;
    normalizeBiquad(b0,b1,b2,a0,a1,a2); this->b0=b0; this->b1=b1; this->b2=b2; this->a1=a1; this->a2=a2;
}

void AmpCore::Biquad::setHighPass(float sr, float frequency, float q) noexcept {
    const float w0 = 2.0f * kPi * safeFrequency(frequency, sr) / sr;
    const float c = std::cos(w0), alpha = std::sin(w0) / (2.0f * q);
    float b0=(1.0f+c)*0.5f, b1=-(1.0f+c), b2=(1.0f+c)*0.5f;
    float a0=1.0f+alpha, a1=-2.0f*c, a2=1.0f-alpha;
    normalizeBiquad(b0,b1,b2,a0,a1,a2); this->b0=b0; this->b1=b1; this->b2=b2; this->a1=a1; this->a2=a2;
}

void AmpCore::Biquad::setLowPass(float sr, float frequency, float q) noexcept {
    const float w0 = 2.0f * kPi * safeFrequency(frequency, sr) / sr;
    const float c = std::cos(w0), alpha = std::sin(w0) / (2.0f * q);
    float b0=(1.0f-c)*0.5f, b1=1.0f-c, b2=(1.0f-c)*0.5f;
    float a0=1.0f+alpha, a1=-2.0f*c, a2=1.0f-alpha;
    normalizeBiquad(b0,b1,b2,a0,a1,a2); this->b0=b0; this->b1=b1; this->b2=b2; this->a1=a1; this->a2=a2;
}


float AmpCore::lookupTanh(float x) const noexcept {
    const float scaled = (std::clamp(x, -8.0f, 8.0f) + 8.0f) *
                         (static_cast<float>(LutSize - 1) / 16.0f);
    const auto index = static_cast<std::size_t>(scaled);
    const auto next = std::min(index + 1, static_cast<std::size_t>(LutSize - 1));
    const float fraction = scaled - static_cast<float>(index);
    return m_lut[index] + (m_lut[next] - m_lut[index]) * fraction;
}

float AmpCore::tubeStage(float x, float drive, float asymmetry) const noexcept {
    const float biased = (x + asymmetry * 0.075f) * drive;
    const float clipped = lookupTanh(biased);
    const float normalized = lookupTanh(asymmetry * 0.075f * drive);
    return (clipped - normalized) / std::max(0.15f, lookupTanh(drive * 0.85f));
}

float AmpCore::dbToLinear(float db) noexcept { return std::pow(10.0f, db / 20.0f); }

void AmpCore::configure(ChannelState& st, int sampleRate, const AmpSettings& s) noexcept {
    const float sr = static_cast<float>(std::clamp(sampleRate, static_cast<int>(kMinSampleRate), static_cast<int>(kMaxSampleRate)));
    st.inputHighPass.setHighPass(sr, 58.0f, 0.72f);

    // Separate passive-style tone stacks: Clean EQ is independent of OD EQ.
    st.cleanBass.setLowShelf(sr, 145.0f, controlToDb(clampControl(s.cleanBass)));
    st.cleanMid.setPeak(sr, 720.0f, 0.72f, controlToDb(clampControl(s.cleanMiddle)));
    st.cleanTreble.setHighShelf(sr, 2600.0f, controlToDb(clampControl(s.cleanTreble)));
    st.cleanBright.setHighShelf(sr, 3400.0f, 3.0f);

    st.odBass.setLowShelf(sr, 125.0f, controlToDb(clampControl(s.odBass)));
    st.odMid.setPeak(sr, 760.0f, 0.78f, controlToDb(clampControl(s.odMiddle)));
    st.odTreble.setHighShelf(sr, 2850.0f, controlToDb(clampControl(s.odTreble)));
    const float scoopCut = s.channel == Channel::OD1 ? -4.0f : -6.0f;
    const bool activeScoop = (s.channel == Channel::OD1 && s.od1Scoop) || (s.channel == Channel::OD2 && s.od2Scoop);
    st.odScoopMid.setPeak(sr, 760.0f, 0.58f, activeScoop ? scoopCut : 0.0f);

    st.cabHighPass.setHighPass(sr, 72.0f + (clampControl(s.cabinetResonance) - 5.0f) * 2.0f, 0.75f);
    st.cabLowPass.setLowPass(sr, 5600.0f + (clampControl(s.presence) - 5.0f) * 150.0f, 0.72f);
    st.cabResonance.setPeak(sr, 125.0f, 1.1f, (clampControl(s.cabinetResonance) - 5.0f) * 1.25f);
}

void AmpCore::process(float* audio, std::size_t frames, int channels, int sampleRate,
                      const AmpSettings& inputSettings) noexcept {
    if (!audio || frames == 0 || channels <= 0 || channels > 2 || sampleRate < 8000) return;

    AmpSettings s = inputSettings;
    s.cleanGain = clampControl(s.cleanGain); s.cleanVolume = clampControl(s.cleanVolume);
    s.cleanBass = clampControl(s.cleanBass); s.cleanMiddle = clampControl(s.cleanMiddle); s.cleanTreble = clampControl(s.cleanTreble);
    s.od1Gain = clampControl(s.od1Gain); s.od1Volume = clampControl(s.od1Volume);
    s.od2Gain = clampControl(s.od2Gain); s.od2Volume = clampControl(s.od2Volume);
    s.odBass = clampControl(s.odBass); s.odMiddle = clampControl(s.odMiddle); s.odTreble = clampControl(s.odTreble);
    s.masterVolume = clampControl(s.masterVolume); s.presence = clampControl(s.presence);
    s.powerSag = clampControl(s.powerSag); s.cabinetResonance = clampControl(s.cabinetResonance);

    for (auto& st : m_state) configure(st, sampleRate, s);

    const float cleanGain = s.cleanGain;
    const float od1Gain = s.od1Gain;
    const float od2Gain = s.od2Gain;
    const float channelVolume = s.channel == Channel::Clean ? s.cleanVolume :
                                (s.channel == Channel::OD1 ? s.od1Volume : s.od2Volume);
    const float volumeGain = dbToLinear((channelVolume - 5.0f) * 2.5f);
    const float masterGain = dbToLinear((s.masterVolume - 5.0f) * 2.0f);
    const float presenceGain = dbToLinear((s.presence - 5.0f) * 1.15f);
    const float sagDepth = 0.015f + s.powerSag * 0.0085f;
    const float sagRelease = std::exp(-1.0f / (static_cast<float>(sampleRate) * 0.18f));
    const float sagAttack = std::exp(-1.0f / (static_cast<float>(sampleRate) * 0.012f));

    for (std::size_t frame = 0; frame < frames; ++frame) {
        for (int ch = 0; ch < channels; ++ch) {
            auto& st = m_state[ch];
            float x = audio[frame * static_cast<std::size_t>(channels) + static_cast<std::size_t>(ch)];
            if (!std::isfinite(x)) x = 0.0f;
            x = std::clamp(x, -4.0f, 4.0f);
            x = st.inputHighPass.run(x);

            if (s.channel == Channel::Clean) {
                const float gain = 0.85f + cleanGain * 0.31f;
                if (s.cleanBright) x = st.cleanBright.run(x);
                x = tubeStage(x, gain, 0.18f);
                x = tubeStage(x, 1.05f + cleanGain * 0.075f, 0.12f);
                x = st.cleanBass.run(x);
                x = st.cleanMid.run(x);
                x = st.cleanTreble.run(x);
            } else {
                const bool isOD1 = s.channel == Channel::OD1;
                const float gain = isOD1 ? od1Gain : od2Gain;
                const float drive = isOD1 ? (1.35f + gain * gain * 0.105f)
                                          : (2.0f + gain * gain * 0.17f);
                // A preamp low cut keeps high-gain sounds controlled without removing body.
                x = tubeStage(x * (isOD1 ? 1.22f : 1.34f), drive, isOD1 ? 0.30f : 0.48f);
                x = tubeStage(x, isOD1 ? 1.25f : 1.70f, isOD1 ? 0.25f : 0.42f);
                if (!isOD1) x = tubeStage(x, 1.28f + gain * 0.035f, 0.36f);
                x *= isOD1 ? 1.20f : 1.12f;
                x = st.odBass.run(x);
                x = st.odMid.run(x);
                x = st.odTreble.run(x);

                const bool scoop = isOD1 ? s.od1Scoop : s.od2Scoop;
                if (scoop) {
                    // Broad contour switch: low/high emphasis plus a dedicated mid notch.
                    const float scoopLow = dbToLinear(isOD1 ? 1.8f : 3.0f);
                    const float scoopHigh = dbToLinear(isOD1 ? 1.0f : 2.0f);
                    x = st.odScoopMid.run(x * scoopLow) * scoopHigh;
                }
            }

            // Shared power section: gentle envelope-dependent supply compression.
            const float magnitude = std::abs(x);
            const float coeff = magnitude > st.sagEnvelope ? sagAttack : sagRelease;
            st.sagEnvelope = coeff * st.sagEnvelope + (1.0f - coeff) * magnitude;
            const float sagGain = 1.0f - std::min(0.22f, st.sagEnvelope * sagDepth);
            x *= sagGain;
            x = tubeStage(x, 1.15f, 0.22f);
            x *= volumeGain * masterGain;

            if (s.cabinetEnabled) {
                x = st.cabHighPass.run(x);
                x = st.cabResonance.run(x);
                x = st.cabLowPass.run(x * presenceGain);
            } else {
                x *= presenceGain;
            }

            // DC blocking and final safety ceiling.
            const float dc = x - st.dcIn + 0.995f * st.dcOut;
            st.dcIn = x; st.dcOut = std::isfinite(dc) ? dc : 0.0f;
            x = std::clamp(st.dcOut, -1.0f, 1.0f);
            audio[frame * static_cast<std::size_t>(channels) + static_cast<std::size_t>(ch)] = x;
        }
    }
}

} // namespace artms
