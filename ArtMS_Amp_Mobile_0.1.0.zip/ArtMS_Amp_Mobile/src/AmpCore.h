#pragma once

#include "AmpSettings.h"
#include <cstddef>
#include <vector>

namespace artms {

class AmpCore {
public:
    AmpCore();
    void reset() noexcept;

    // Interleaved mono/stereo float audio, normalized to approximately [-1, 1].
    // Call reset() before a new independent file. State is preserved across blocks.
    void process(float* interleaved, std::size_t frames, int channels,
                 int sampleRate, const AmpSettings& settings) noexcept;

    void process(std::vector<float>& interleaved, int channels,
                 int sampleRate, const AmpSettings& settings) noexcept {
        if (channels <= 0) return;
        process(interleaved.data(), interleaved.size() / static_cast<std::size_t>(channels),
                channels, sampleRate, settings);
    }

private:
    struct Biquad {
        float b0 = 1.0f, b1 = 0.0f, b2 = 0.0f, a1 = 0.0f, a2 = 0.0f;
        float z1 = 0.0f, z2 = 0.0f;
        float run(float x) noexcept;
        void setLowShelf(float sampleRate, float frequency, float gainDb) noexcept;
        void setHighShelf(float sampleRate, float frequency, float gainDb) noexcept;
        void setPeak(float sampleRate, float frequency, float q, float gainDb) noexcept;
        void setHighPass(float sampleRate, float frequency, float q = 0.7071f) noexcept;
        void setLowPass(float sampleRate, float frequency, float q = 0.7071f) noexcept;
    };

    struct ChannelState {
        Biquad inputHighPass;
        Biquad cleanBass, cleanMid, cleanTreble, cleanBright;
        Biquad odBass, odMid, odTreble, odScoopMid;
        Biquad cabHighPass, cabLowPass, cabResonance;
        float sagEnvelope = 0.0f;
        float dcIn = 0.0f;
        float dcOut = 0.0f;
    };

    static constexpr int LutSize = 8193;
    float lookupTanh(float x) const noexcept;
    float tubeStage(float x, float drive, float asymmetry) const noexcept;
    static float dbToLinear(float db) noexcept;
    void configure(ChannelState& state, int sampleRate, const AmpSettings& s) noexcept;

    std::vector<float> m_lut;
    ChannelState m_state[2];
};

} // namespace artms
