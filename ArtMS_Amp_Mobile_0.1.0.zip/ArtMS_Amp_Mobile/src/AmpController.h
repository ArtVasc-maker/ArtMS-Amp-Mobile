#pragma once

#include "AmpSettings.h"
#include <QObject>
#include <QFutureWatcher>
#include <QUrl>
#include <QVariantMap>

namespace artms {

class AmpController final : public QObject {
    Q_OBJECT
    Q_PROPERTY(QVariantMap parameters READ parameters NOTIFY parametersChanged)
    Q_PROPERTY(QString channel READ channel NOTIFY channelChanged)
    Q_PROPERTY(QString status READ status NOTIFY statusChanged)
    Q_PROPERTY(QString inputName READ inputName NOTIFY inputChanged)
    Q_PROPERTY(QUrl outputUrl READ outputUrl NOTIFY outputChanged)
    Q_PROPERTY(bool hasInput READ hasInput NOTIFY inputChanged)
    Q_PROPERTY(bool hasOutput READ hasOutput NOTIFY outputChanged)
    Q_PROPERTY(bool busy READ busy NOTIFY busyChanged)

public:
    explicit AmpController(QObject* parent = nullptr);

    QVariantMap parameters() const { return m_parameters; }
    QString channel() const { return m_channel; }
    QString status() const { return m_status; }
    QString inputName() const { return m_inputName; }
    QUrl outputUrl() const { return m_outputUrl; }
    bool hasInput() const { return m_inputUrl.isValid(); }
    bool hasOutput() const { return m_outputUrl.isValid(); }
    bool busy() const { return m_busy; }

    Q_INVOKABLE void setInputUrl(const QUrl& url);
    Q_INVOKABLE void setChannel(const QString& channel);
    Q_INVOKABLE void setParameter(const QString& name, double value);
    Q_INVOKABLE void setToggle(const QString& name, bool value);
    Q_INVOKABLE void processInput();
    Q_INVOKABLE void clearOutput();

signals:
    void parametersChanged();
    void channelChanged();
    void statusChanged();
    void inputChanged();
    void outputChanged();
    void busyChanged();

private:
    struct JobResult { bool ok = false; QString message; QString path; };
    void refreshMap();
    void setStatus(const QString& value);
    void setBusy(bool value);

    AmpSettings m_settings;
    QVariantMap m_parameters;
    QString m_channel = QStringLiteral("CLEAN");
    QString m_status = QStringLiteral("Importe um WAV DI para começar.");
    QString m_inputName;
    QUrl m_inputUrl;
    QUrl m_outputUrl;
    bool m_busy = false;
    QFutureWatcher<JobResult> m_watcher;
};

} // namespace artms
