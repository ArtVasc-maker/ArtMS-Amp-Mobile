#include "AmpCore.h"
#include "WavIO.h"

#include <cmath>
#include <cstdio>
#include <iostream>
#include <string>
#include <vector>

namespace {
bool check(bool condition, const char* message) {
    if (!condition) std::cerr << "FAIL: " << message << '\n';
    return condition;
}
}

int main() {
    bool ok = true;
    constexpr int sampleRate = 48000;
    constexpr int channels = 2;
    constexpr std::size_t frames = 48000;
    std::vector<float> input(frames * channels);
    for (std::size_t i = 0; i < frames; ++i) {
        const float v = 0.20f * std::sin(2.0f * 3.14159265358979323846f * 110.0f * static_cast<float>(i) / sampleRate)
                      + 0.08f * std::sin(2.0f * 3.14159265358979323846f * 880.0f * static_cast<float>(i) / sampleRate);
        input[i * 2] = v;
        input[i * 2 + 1] = v;
    }

    artms::AmpSettings settings;
    artms::AmpCore core;
    auto clean = input;
    settings.channel = artms::Channel::Clean;
    core.reset();
    core.process(clean, channels, sampleRate, settings);
    bool finiteClean = true;
    for (float v : clean) finiteClean = finiteClean && std::isfinite(v);
    ok &= check(finiteClean, "Clean output must remain finite");

    auto od1 = input;
    settings.channel = artms::Channel::OD1;
    settings.od1Gain = 7.0f;
    settings.od1Scoop = true;
    core.reset();
    core.process(od1, channels, sampleRate, settings);
    bool finiteOD1 = true;
    for (float v : od1) finiteOD1 = finiteOD1 && std::isfinite(v);
    ok &= check(finiteOD1, "OD1 output must remain finite");

    auto od2 = input;
    settings.channel = artms::Channel::OD2;
    settings.od2Gain = 8.0f;
    settings.od2Scoop = true;
    core.reset();
    core.process(od2, channels, sampleRate, settings);
    bool finiteOD2 = true;
    for (float v : od2) finiteOD2 = finiteOD2 && std::isfinite(v);
    ok &= check(finiteOD2, "OD2 output must remain finite");

    double diffCleanOD1 = 0.0, diffOD1OD2 = 0.0;
    for (std::size_t i = 0; i < input.size(); ++i) {
        diffCleanOD1 += std::abs(static_cast<double>(clean[i] - od1[i]));
        diffOD1OD2 += std::abs(static_cast<double>(od1[i] - od2[i]));
    }
    ok &= check(diffCleanOD1 > 1.0, "Clean and OD1 should produce distinct processing");
    ok &= check(diffOD1OD2 > 1.0, "OD1 and OD2 should produce distinct processing");

    // Clean EQ must not bleed into OD; Overdrive EQ must affect both OD channels.
    artms::AmpSettings topology;
    topology.channel = artms::Channel::OD1;
    auto odBaseline = input;
    core.reset();
    core.process(odBaseline, channels, sampleRate, topology);
    topology.cleanBass = 10.0f;
    auto odWithCleanEqChanged = input;
    core.reset();
    core.process(odWithCleanEqChanged, channels, sampleRate, topology);
    double cleanEqBleed = 0.0;
    for (std::size_t i = 0; i < input.size(); ++i)
        cleanEqBleed += std::abs(static_cast<double>(odBaseline[i] - odWithCleanEqChanged[i]));
    ok &= check(cleanEqBleed < 1.0e-5, "Clean EQ must remain isolated from OD channels");

    topology.cleanBass = 5.0f;
    topology.odBass = 9.0f;
    auto odWithOdEqChanged = input;
    core.reset();
    core.process(odWithOdEqChanged, channels, sampleRate, topology);
    double odEqEffect = 0.0;
    for (std::size_t i = 0; i < input.size(); ++i)
        odEqEffect += std::abs(static_cast<double>(odBaseline[i] - odWithOdEqChanged[i]));
    ok &= check(odEqEffect > 0.1, "Shared Overdrive EQ must affect OD1");

    // OD1 Scoop must not activate OD2's contour and vice versa.
    topology.channel = artms::Channel::OD2;
    topology.od1Scoop = true;
    topology.od2Scoop = false;
    auto od2NoScoop = input;
    core.reset();
    core.process(od2NoScoop, channels, sampleRate, topology);
    topology.od1Scoop = false;
    auto od2AfterOd1ScoopToggle = input;
    core.reset();
    core.process(od2AfterOd1ScoopToggle, channels, sampleRate, topology);
    double scoopBleed = 0.0;
    for (std::size_t i = 0; i < input.size(); ++i)
        scoopBleed += std::abs(static_cast<double>(od2NoScoop[i] - od2AfterOd1ScoopToggle[i]));
    ok &= check(scoopBleed < 1.0e-5, "OD1 Scoop must not affect OD2");

    artms::AudioFile wav;
    wav.sampleRate = sampleRate;
    wav.channels = 2;
    wav.samples = input;
    std::string error;
    const std::string tempPath = "artms_amp_test_roundtrip.wav";
    ok &= check(artms::writeWav16(tempPath, wav, error), "WAV writer should succeed");
    artms::AudioFile decoded;
    ok &= check(artms::readWav(tempPath, decoded, error), "WAV reader should read its own output");
    ok &= check(decoded.channels == 2 && decoded.sampleRate == sampleRate && decoded.samples.size() == input.size(),
                "WAV roundtrip metadata should be preserved");
    std::remove(tempPath.c_str());

    if (!ok) return 1;
    std::cout << "PASS: Clean, OD1, OD2, finite output and WAV round-trip.\n";
    return 0;
}
